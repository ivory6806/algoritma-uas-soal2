#include "main.h"

void inputMatkul(struct khs mk[], int n){
    printf("\n===== INPUT MATA KULIAH =====\n");
    for(int i=0;i<n;i++){
        printf("Mata Kuliah ke-%d\n", i+1);
        printf("Kode  : "); scanf("%s", mk[i].kode);
        printf("Nama  : "); scanf("%s", mk[i].matkul);getchar();
        printf("SKS   : "); scanf("%d", &mk[i].sks);
    }
}
