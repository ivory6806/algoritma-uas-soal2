void biodatakelompok(){
    printf("------------- Kelompok 1 -------------\n");
    printf("251110018 - Ari Andrean \n");
    printf("251110014 - Ivory Alva Dias Kurniawan \n");
    printf("251110010 - Adhitiya Agung Kurniawan \n");
    printf("251110072 - Rizal Zaelani \n");
    printf("251110065 - Wira Suteratama \n \n");
}
