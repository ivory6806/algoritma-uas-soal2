#include "main.h"

void inputNilai(struct khs mk[], int n) {
    printf("\n--- Input Nilai Semester ---\n");
    for(int i=0;i<n;i++){
        printf("Nilai untuk %s - %s : ", mk[i].kode, mk[i].matkul);
        scanf(" %c", &mk[i].nilai);
    }
}
