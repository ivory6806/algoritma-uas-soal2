#include "main.h"

void tampilkanKHS(struct biodatakhs mhs, struct khs mk[], int n){
    printf("No | Kode MK | Mata Kuliah | SKS | Nilai | Bobot | NS\n");
    printf("-----------------------------------------------------\n");
    for(int i=0;i<n;i++){
        printf("%2d | %-7s | %-12s | %3d |   %c   | %3d  | %3d\n",
            i + 1, mk[i].kode, mk[i].matkul, mk[i].sks, mk[i].nilai, mk[i].bobot, mk[i].ns);
    }

    printf("\nTotal SKS: %d\n", mk[0].jml_sks);
    printf("IPS      : %.2f\n", mk[0].ips);
    printf("=================================\n");
}
